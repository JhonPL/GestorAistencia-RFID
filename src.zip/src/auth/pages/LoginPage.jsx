import { useEffect, useContext, useRef } from 'react';
import { displayThemeButtons, startAutoTheme } from './themes';
import "./LoginPage.css";
import { AuthContext } from '../context';
import { useNavigate } from 'react-router-dom';

export const LoginPage = () => {
    useEffect(() => {
        displayThemeButtons();
        startAutoTheme(5000);
    }, []);

    const {login} = useContext(AuthContext);
    const navigate = useNavigate();
    const userRef = useRef();
    const passRef = useRef();

    const handleSubmit = async (e) => {
        e.preventDefault();
        const correo = userRef.current.value;
        const password = passRef.current.value;

        try {
            const res = await fetch("http://localhost:3000/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ correo, password }),
            });
            const data = await res.json();
            if (res.ok) {
                localStorage.setItem("token", data.token);
                login(correo);
                navigate("/cursos");
            } else {
                alert(data.mensaje || "Login fallido");
            }
        } catch {
            alert("Error en la conexión");
        }
    };

    return (
        <>
            <div className="main-container">
                <section className="container">
                    <div className="login-container">
                        <div className="circle circle-one"></div>
                        <div className="form-container">
                            <img src="https://raw.githubusercontent.com/hicodersofficial/glassmorphism-login-form/master/assets/illustration.png" alt="illustration" className="illustration" />
                            <h1 className="opacity">LOGIN</h1>
                            <form onSubmit={handleSubmit}>
                                <input ref={userRef} type="text" placeholder="USERNAME" />
                                <input ref={passRef} type="password" placeholder="PASSWORD" />
                                <button className="opacity">Iniciar Sesión</button>
                            </form>
                            <div className="register-forget opacity">
                            </div>
                        </div>
                        <div className="circle circle-two"></div>
                    </div>
                    <div className="theme-btn-container"></div>
                </section>
            </div>
        </>
    )
}